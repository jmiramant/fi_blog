<?php
/**
 * The template for Footer.
 *
 * @package Simon WP Framework
 * @since Simon WP Framework 1.0
 */
?>

<!-- <div style="clear: both"></div>
<div id="footer">
  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer1") ) : ?>
  <?php endif; ?>
  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer2") ) : ?>
  <?php endif; ?>
  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer3") ) : ?>
  <?php endif; ?>
 --> <div style="clear: both"></div>
  <?php ?> </div>


<!-- <?php wp_footer(); ?> -->
<div>
	<div id="footer" class="container">
				<p class="left">
					<span class="copyright">&copy; 2013 EverFi, Inc.&reg;</span><br />
					<a href="http://everfi.com/legal/privacy">Privacy</a> <b class="bar">|</b>
					<a href="http://everfi.com/legal/terms-of-use">Terms</a>
				</p>

				<ul class="connect right dotrm">
					<li><a href="http://twitter.com/everfi" class="twitter">Twitter</a></li>
					<li><a href="http://www.facebook.com/everfi" class="facebook">Facebook</a></li>
					<li><a href="http://www.linkedin.com/company/everfi" class="linkedin">Linkedin</a></li>
				</ul>
			</div>
			
		</div>
	</div>
</body></html>